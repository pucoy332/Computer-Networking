from socket import *
import time

message_text = 'ping'

clientSocket = socket(AF_INET, SOCK_DGRAM)

clientSocket.settimeout(1)

# IP 주소랑 port number 생성
addr = ('localhost', 12000)

# 서버로 메시지 10개 send
for i in range(10):
    send_time = time.time()
    message_to_send = '{} {} {}'.format(message_text, (i + 1), time.strftime("%H:%M:%S"))
    clientSocket.sendto(message_to_send, addr)

    print('========================================================')
    try:
        received_message, server = clientSocket.recvfrom(1024)
        received_time = time.time()
        RTT = received_time - send_time
        print('Message to Send: \'{}\''.format(message_to_send))
        print('Response Message: \'{}\''.format(received_message))
        print('Round Trip Time: {}'.format(RTT))

    except timeout:
        print('Request Timed Out {}'.format(i + 1))
    print('========================================================')

clientSocket.close()